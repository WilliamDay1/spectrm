# Spectrm — Auto-updating data layer

## How it works

```
GitHub repo (this)
├── data/           ← JSON files, auto-updated by scripts
├── scripts/        ← Python fetch scripts
├── .github/
│   └── workflows/  ← GitHub Actions (scheduled jobs)
└── spectrum.html   ← your frontend (reads from /data/*.json)
```

GitHub Actions runs the scripts on a schedule. Each script fetches
fresh data, updates the relevant JSON file, and commits it back.
Vercel detects the commit and redeploys automatically (under 30 seconds).

## Update schedule

| File | Script | Schedule | Source |
|------|--------|----------|--------|
| `data/news.json` | `fetch_news.py` | Daily 06:30 UTC | BBC/Guardian/Reuters RSS |
| `data/economic.json` | `fetch_economic.py` | Daily 06:30 UTC | ONS API, BoE, NHS England |
| `data/polls.json` | `fetch_polls.py` | Weekly (Mon) 07:00 UTC | Wikipedia polling table |
| `data/manifesto.json` | `fetch_manifesto.py` | Monthly (1st) 08:00 UTC | Full Fact scrape |

## Deployment (Vercel)

1. Push this repo to GitHub
2. Connect to Vercel: https://vercel.com/new → Import Git Repository
3. No build step needed — Vercel serves `spectrum.html` as a static site
4. Set root directory to `/` and output directory to `/`
5. Done — your site is live at `[project].vercel.app`

## Updating data manually

Edit any file in `data/` and push to GitHub. Vercel redeploys in ~30s.

```bash
# Example: add a new poll result
vim data/polls.json   # or use any text editor
git add data/polls.json
git commit -m "add YouGov poll 29 Jun 2026"
git push
```

## Running scripts locally

```bash
cd scripts
python fetch_news.py
python fetch_economic.py
python fetch_polls.py
python fetch_manifesto.py
```

No dependencies beyond Python 3.12 stdlib (no pip installs needed).

## What's automatically updated vs manual

**Auto (no action needed):**
- News headlines — replaced daily with latest BBC/Guardian/Reuters stories
- CPI, unemployment, BoE rate, gilt yield — updated when ONS/BoE publish
- NHS waiting list — updated monthly when NHS England publishes
- Polling averages — recomputed weekly from Wikipedia table
- Manifesto pledge statuses — scraped monthly from Full Fact

**Manual (you update when things change):**
- Calendar events (elections, debates, summits)
- Leadership contest status and candidates  
- Major political developments not covered by RSS
- Manifesto pledges that Full Fact hasn't yet assessed

To update manual data, edit `data/polls.json` (for leadership/contests)
and the EVENTS array in `spectrum.html` (for calendar), then push.
