#!/usr/bin/env python3
"""
fetch_polls.py
Fetches latest UK polling data.
Runs weekly (Mondays) via GitHub Actions.

Sources:
  - Wikipedia UK opinion polling page (community-maintained, fast)
  - WhatUKThinks dataset CSV (academic quality, slightly slower)

The script computes a simple 7-poll moving average.
"""

import csv
import json
import os
import re
import sys
import urllib.request
from datetime import datetime, date
from io import StringIO

DATA_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'polls.json')

# Wikipedia polling table URL
WIKI_URL = 'https://en.wikipedia.org/wiki/Opinion_polling_for_the_next_United_Kingdom_general_election'

# WhatUKThinks CSV
WUKT_CSV_URL = 'https://whatukthinks.org/eu/wp-content/uploads/all_poll_data_EU.csv'

PARTY_COLS = {
    'con': ['Conservative', 'Con'],
    'lab': ['Labour', 'Lab'],
    'lib': ['Liberal Democrats', 'Lib Dem', 'LD'],
    'ref': ['Reform UK', 'Reform'],
    'grn': ['Green', 'Grn'],
    'snp': ['SNP'],
}


def fetch_text(url: str) -> str:
    try:
        req = urllib.request.Request(
            url,
            headers={'User-Agent': 'Spectrm/1.0 (+https://spectrm.app); academic data journalism'}
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"  WARNING: Could not fetch {url}: {e}", file=sys.stderr)
        return ''


def parse_wikipedia_polls(html: str) -> list[dict]:
    """
    Extract poll rows from Wikipedia polling table.
    Returns list of dicts with keys: date, pollster, lab, con, lib, ref, grn
    """
    polls = []
    
    # Find the main polling table — look for rows with percentage patterns
    # Wikipedia tables use wikitable class
    table_pattern = r'<table[^>]*wikitable[^>]*>(.*?)</table>'
    tables = re.findall(table_pattern, html, re.DOTALL | re.IGNORECASE)
    
    for table in tables:
        rows = re.findall(r'<tr[^>]*>(.*?)</tr>', table, re.DOTALL | re.IGNORECASE)
        
        # Find header row to identify column positions
        header_row = ''
        col_map = {}
        for row in rows[:5]:
            cells = re.findall(r'<t[hd][^>]*>(.*?)</t[hd]>', row, re.DOTALL | re.IGNORECASE)
            clean = [re.sub(r'<[^>]+>', '', c).strip() for c in cells]
            if any(p in ' '.join(clean) for p in ['Labour', 'Conservative', 'Reform']):
                header_row = clean
                for party, names in PARTY_COLS.items():
                    for name in names:
                        for i, h in enumerate(clean):
                            if name.lower() in h.lower():
                                col_map[party] = i
                                break
                break
        
        if not col_map:
            continue
        
        # Parse data rows
        for row in rows[1:]:
            cells = re.findall(r'<t[hd][^>]*>(.*?)</t[hd]>', row, re.DOTALL | re.IGNORECASE)
            clean = [re.sub(r'<[^>]+>', '', c).strip() for c in cells]
            
            if len(clean) < 3:
                continue
            
            poll = {}
            for party, col_idx in col_map.items():
                if col_idx < len(clean):
                    val_str = re.sub(r'[^0-9.]', '', clean[col_idx])
                    try:
                        poll[party] = round(float(val_str), 1)
                    except ValueError:
                        pass
            
            # Need at least lab, con, ref to be a valid poll row
            if len(poll) >= 3 and all(0 < poll.get(p, 0) < 60 for p in ['lab', 'con']):
                # Try to get date from first column
                date_str = clean[0] if clean else ''
                poll['date_str'] = date_str
                
                # Try to get pollster
                if len(clean) > 1:
                    poll['pollster'] = clean[1]
                
                polls.append(poll)
        
        if polls:
            break  # Found the right table
    
    return polls[:20]  # Return most recent 20


def compute_average(polls: list[dict], n: int = 7) -> dict:
    """Compute simple unweighted average of n most recent polls."""
    recent = polls[:n]
    if not recent:
        return {}
    
    avg = {}
    for party in ['lab', 'con', 'lib', 'ref', 'grn', 'snp']:
        values = [p[party] for p in recent if party in p]
        if values:
            avg[party] = round(sum(values) / len(values), 1)
    
    return avg


def load_current() -> dict:
    try:
        with open(DATA_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def main():
    print(f"fetch_polls.py — {datetime.now().isoformat()}")
    current = load_current()
    
    print("Fetching Wikipedia polling table...")
    html = fetch_text(WIKI_URL)
    
    if html:
        polls = parse_wikipedia_polls(html)
        print(f"  Parsed {len(polls)} polls")
        
        if polls:
            avg = compute_average(polls)
            print(f"  New 7-poll average: {avg}")
            
            old_avg = current.get('average', {})
            
            # Update average
            current['average'] = {
                'date': date.today().isoformat(),
                **avg
            }
            
            # Update monthly history — append if new month
            history = current.get('monthly_history', {})
            today_label = datetime.now().strftime('%b %y')
            labels = history.get('labels', [])
            
            if labels and labels[-1] != today_label:
                # New month — append
                for party in ['ref', 'lab', 'con', 'grn', 'lib']:
                    history.setdefault(party, []).append(avg.get(party, 0))
                labels.append(today_label)
                history['labels'] = labels
                print(f"  Appended new month: {today_label}")
            elif labels:
                # Same month — update last point
                for party in ['ref', 'lab', 'con', 'grn', 'lib']:
                    if party in history and history[party]:
                        history[party][-1] = avg.get(party, history[party][-1])
                print(f"  Updated current month: {today_label}")
            
            current['monthly_history'] = history
    else:
        print("  Could not fetch Wikipedia data, keeping existing averages")
    
    current['_meta'] = current.get('_meta', {})
    current['_meta']['updated'] = date.today().isoformat()
    
    with open(DATA_FILE, 'w') as f:
        json.dump(current, f, indent=2)
    
    print(f"Saved {DATA_FILE}")


if __name__ == '__main__':
    main()
