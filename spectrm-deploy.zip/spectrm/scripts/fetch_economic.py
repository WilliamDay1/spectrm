#!/usr/bin/env python3
"""
fetch_economic.py
Fetches latest economic indicators from ONS API, BoE, and NHS England.
Runs daily via GitHub Actions. Updates data/economic.json.

Sources:
  - ONS API v2: api.ons.gov.uk/v2/datasets/{id}/timeseries/{series}/data
  - BoE Statistical Interactive Database
  - NHS England RTT waiting times open data
"""

import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime, date

DATA_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'economic.json')

# ── ONS series IDs ─────────────────────────────────────────────────────────────
ONS_SERIES = {
    # CPI 12-month rate — dataset MM23
    'cpi': ('mm23', 'D7G7'),
    # Unemployment rate (16+, seasonally adjusted) — dataset LMS
    'unemployment': ('lms', 'MGSX'),
}

# ── BoE series codes ──────────────────────────────────────────────────────────
BOE_SERIES = {
    # Official Bank Rate
    'boe_rate': 'IUDBEDR',
    # 10yr gilt nominal yield
    'gilt_10yr': 'IUDMNPY',
}


def fetch_json(url: str, timeout: int = 10) -> dict:
    """Fetch JSON from a URL, return empty dict on failure."""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Spectrm/1.0 (+https://spectrm.app)'})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"  WARNING: Could not fetch {url}: {e}", file=sys.stderr)
        return {}


def fetch_ons_latest(dataset: str, series: str) -> float | None:
    """Fetch the latest monthly value from the ONS API v2."""
    url = f"https://api.ons.gov.uk/v2/datasets/{dataset}/timeseries/{series}/data"
    data = fetch_json(url)
    months = data.get('months', [])
    if not months:
        return None
    # Last item is most recent
    latest = months[-1]
    try:
        return float(latest.get('value', '').replace(',', ''))
    except (ValueError, AttributeError):
        return None


def fetch_ons_history(dataset: str, series: str, n: int = 25) -> list[float]:
    """Fetch the last n monthly values from ONS."""
    url = f"https://api.ons.gov.uk/v2/datasets/{dataset}/timeseries/{series}/data"
    data = fetch_json(url)
    months = data.get('months', [])
    values = []
    for m in months[-n:]:
        try:
            values.append(round(float(m.get('value', '0').replace(',', '')), 2))
        except (ValueError, AttributeError):
            values.append(0.0)
    return values


def fetch_boe_latest(series: str) -> float | None:
    """Fetch latest value from BoE IADB CSV endpoint."""
    # BoE provides CSV; we take the last non-empty row
    url = f"https://www.bankofengland.co.uk/boeapps/database/fromshowcolumns.asp?Travel=NIxRSxSUx&FromSeries=1&ToSeries=50&DAT=RNG&FD=1&FM=Jan&FY=2020&TD=1&TM=Jan&TY=2099&VFD=Y&html.x=66&html.y=26&C={series}&Filter=N"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Spectrm/1.0'})
        with urllib.request.urlopen(req, timeout=10) as resp:
            lines = resp.read().decode('utf-8', errors='ignore').splitlines()
        # Find data rows (skip header until we see date-like pattern)
        values = []
        for line in lines:
            parts = line.split(',')
            if len(parts) >= 2:
                try:
                    val = float(parts[-1].strip())
                    values.append(val)
                except ValueError:
                    pass
        return values[-1] if values else None
    except Exception as e:
        print(f"  WARNING: BoE fetch failed for {series}: {e}", file=sys.stderr)
        return None


def fetch_nhs_waiting() -> float | None:
    """
    Fetch NHS England RTT waiting times (total waiting list size).
    NHS England publishes monthly CSV at:
    https://www.england.nhs.uk/statistics/statistical-work-areas/rtt-waiting-times/
    We use their open data API endpoint.
    """
    # NHS England open data — RTT incomplete pathways total
    url = "https://www.england.nhs.uk/statistics/wp-content/uploads/sites/2/RTT-data-recent.json"
    data = fetch_json(url)
    # Structure varies; try common patterns
    total = data.get('total_waiting', data.get('incomplete', {}).get('total'))
    if total:
        try:
            return round(float(total) / 1_000_000, 2)
        except (ValueError, TypeError):
            pass
    return None


def load_current() -> dict:
    """Load the current data file."""
    try:
        with open(DATA_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save(data: dict) -> None:
    """Save updated data file."""
    data['_meta']['updated'] = date.today().isoformat()
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    print(f"Saved {DATA_FILE}")


def main():
    print(f"fetch_economic.py — {datetime.now().isoformat()}")
    current = load_current()
    updated = False

    # ── CPI ────────────────────────────────────────────────────────────────────
    print("Fetching CPI from ONS...")
    cpi = fetch_ons_latest('mm23', 'D7G7')
    if cpi is not None:
        old = current.get('kpis', {}).get('cpi', {}).get('value')
        if old != cpi:
            print(f"  CPI: {old} → {cpi}")
            current.setdefault('kpis', {}).setdefault('cpi', {})['value'] = cpi
            current['kpis']['cpi']['prev'] = old
            updated = True
        else:
            print(f"  CPI unchanged: {cpi}")
    
    # ── Unemployment ───────────────────────────────────────────────────────────
    print("Fetching unemployment from ONS...")
    unemp = fetch_ons_latest('lms', 'MGSX')
    if unemp is not None:
        old = current.get('kpis', {}).get('unemployment', {}).get('value')
        if old != unemp:
            print(f"  Unemployment: {old} → {unemp}")
            current.setdefault('kpis', {}).setdefault('unemployment', {})['value'] = unemp
            current['kpis']['unemployment']['prev'] = old
            updated = True
        else:
            print(f"  Unemployment unchanged: {unemp}")

    # ── BoE base rate ──────────────────────────────────────────────────────────
    print("Fetching BoE base rate...")
    boe = fetch_boe_latest('IUDBEDR')
    if boe is not None:
        old = current.get('kpis', {}).get('boe_rate', {}).get('value')
        if old != boe:
            print(f"  BoE rate: {old} → {boe}")
            current.setdefault('kpis', {}).setdefault('boe_rate', {})['value'] = boe
            current['kpis']['boe_rate']['prev'] = old
            updated = True
        else:
            print(f"  BoE rate unchanged: {boe}")

    # ── 10yr gilt ──────────────────────────────────────────────────────────────
    print("Fetching 10yr gilt yield from BoE...")
    gilt = fetch_boe_latest('IUDMNPY')
    if gilt is not None:
        old = current.get('kpis', {}).get('gilt_10yr', {}).get('value')
        rounded = round(gilt, 2)
        if old != rounded:
            print(f"  10yr gilt: {old} → {rounded}")
            current.setdefault('kpis', {}).setdefault('gilt_10yr', {})['value'] = rounded
            current['kpis']['gilt_10yr']['prev'] = old
            updated = True
        else:
            print(f"  10yr gilt unchanged: {rounded}")

    # ── NHS waiting list ───────────────────────────────────────────────────────
    print("Fetching NHS waiting list...")
    nhs = fetch_nhs_waiting()
    if nhs is not None:
        old = current.get('kpis', {}).get('nhs_waiting', {}).get('value')
        if old != nhs:
            print(f"  NHS waiting: {old}m → {nhs}m")
            current.setdefault('kpis', {}).setdefault('nhs_waiting', {})['value'] = nhs
            current['kpis']['nhs_waiting']['prev'] = old
            updated = True
        else:
            print(f"  NHS waiting unchanged: {nhs}m")

    # ── Chart history (monthly, update last point) ─────────────────────────────
    print("Updating chart history...")
    history = current.get('chart_history', {})
    if cpi and 'cpi' in history:
        history['cpi'][-1] = cpi
    if unemp and 'unemployment' in history:
        history['unemployment'][-1] = unemp
    if boe and 'boe_rate' in history:
        history['boe_rate'][-1] = boe
    if gilt and 'gilt_10yr' in history:
        history['gilt_10yr'][-1] = round(gilt, 2)
    if nhs and 'nhs_waiting' in history:
        history['nhs_waiting'][-1] = nhs
    current['chart_history'] = history

    if updated or True:  # always save to update timestamp
        save(current)
        print("Done.")
    else:
        print("No changes detected.")


if __name__ == '__main__':
    main()
