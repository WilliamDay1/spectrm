#!/usr/bin/env python3
"""
fetch_news.py
Fetches latest political news from free RSS feeds.
Runs daily at 06:00 UTC via GitHub Actions.
Updates data/news.json with the 10 most recent relevant stories.

Sources (all free, no API key needed):
  - BBC Politics RSS
  - The Guardian Politics RSS
  - Reuters UK RSS
  - Sky News Politics RSS
"""

import json
import os
import re
import sys
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

DATA_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'news.json')

FEEDS = [
    {
        'name': 'BBC Politics',
        'url': 'https://feeds.bbci.co.uk/news/politics/rss.xml',
        'tag_class': 'tc-c',
    },
    {
        'name': 'The Guardian Politics',
        'url': 'https://www.theguardian.com/politics/rss',
        'tag_class': 'tc-c',
    },
    {
        'name': 'Reuters UK',
        'url': 'https://feeds.reuters.com/reuters/UKdomesticNews',
        'tag_class': 'tc-c',
    },
    {
        'name': 'Sky News Politics',
        'url': 'https://feeds.skynews.com/feeds/rss/politics.xml',
        'tag_class': 'tc-c',
    },
]

# Keywords → tag mapping for auto-categorisation
TAG_RULES = [
    (['burnham', 'starmer', 'labour leader', 'leadership contest', 'labour party'], 'Leadership', 'ldr'),
    (['reform uk', 'reform party', 'farage', 'nigel farage'], 'Reform', 'tc-ref'),
    (['nhs', 'health service', 'hospital', 'waiting list', 'mental health'], 'NHS', 'tc-h'),
    (['inflation', 'cpi', 'economy', 'gdp', 'bank of england', 'interest rate', 'budget', 'chancellor'], 'Economy', 'tc-e'),
    (['ukraine', 'nato', 'defence', 'military', 'armed forces'], 'Defence', 'tc-d'),
    (['gaza', 'israel', 'palestine', 'middle east'], 'Gaza', 'tc-f'),
    (['immigration', 'asylum', 'migration', 'border'], 'Immigration', 'tc-c'),
    (['housing', 'rent', 'mortgage', 'planning'], 'Housing', 'tc-c'),
    (['climate', 'net zero', 'energy', 'green'], 'Energy', 'tc-e'),
    (['scotland', 'snp', 'devolution', 'wales', 'northern ireland'], 'Devolution', 'tc-c'),
    (['by-election', 'election', 'vote', 'polling', 'poll'], 'Election', 'tc-c'),
    (['parliament', 'commons', 'lords', 'pmqs', 'prime minister'], 'Parliament', 'tc-c'),
]


def fetch_feed(feed: dict) -> list[dict]:
    """Fetch and parse an RSS feed, return list of items."""
    items = []
    try:
        req = urllib.request.Request(
            feed['url'],
            headers={'User-Agent': 'Spectrm/1.0 (+https://spectrm.app)'}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            xml_data = resp.read()
        
        root = ET.fromstring(xml_data)
        ns = {'atom': 'http://www.w3.org/2005/Atom'}
        
        # Handle both RSS 2.0 and Atom
        channel = root.find('channel')
        entries = root.findall('.//item') if channel is not None else root.findall('.//atom:entry', ns)
        
        for entry in entries[:15]:
            title_el = entry.find('title')
            link_el = entry.find('link')
            pub_el = entry.find('pubDate') or entry.find('published')
            
            title = title_el.text if title_el is not None else ''
            # Clean up title — remove source prefix like "BBC News | Politics | "
            title = re.sub(r'^[A-Za-z\s]+\|[A-Za-z\s]+\|\s*', '', title).strip()
            
            link = ''
            if link_el is not None:
                link = link_el.text or link_el.get('href', '')
            
            pub_str = ''
            pub_dt = None
            if pub_el is not None and pub_el.text:
                try:
                    pub_dt = parsedate_to_datetime(pub_el.text)
                    pub_str = pub_dt.strftime('%-d %b %Y')
                except Exception:
                    pub_str = pub_el.text[:20]
            
            if not title or len(title) < 10:
                continue
            
            items.append({
                'title': title,
                'url': link,
                'pub_str': pub_str,
                'pub_dt': pub_dt,
                'source': feed['name'],
            })
    
    except Exception as e:
        print(f"  WARNING: Could not fetch {feed['name']}: {e}", file=sys.stderr)
    
    return items


def categorise(title: str) -> tuple[str, str]:
    """Return (tag_label, tag_class) based on title keywords."""
    lower = title.lower()
    for keywords, tag, cls in TAG_RULES:
        if any(kw in lower for kw in keywords):
            return tag, cls
    return 'Politics', 'tc-c'


def is_relevant(title: str) -> bool:
    """Filter out clearly irrelevant items (sport, entertainment, etc.)."""
    lower = title.lower()
    irrelevant = ['sport', 'football', 'cricket', 'tennis', 'rugby', 'olympics',
                  'celebrity', 'film', 'movie', 'music', 'tv show', 'strictly',
                  'weather', 'recipe', 'fashion', 'travel']
    return not any(word in lower for word in irrelevant)


def deduplicate(items: list[dict]) -> list[dict]:
    """Remove near-duplicate stories based on title similarity."""
    seen = []
    deduped = []
    for item in items:
        # Simple dedup: skip if first 6 words match something we've seen
        key = ' '.join(item['title'].lower().split()[:6])
        if key not in seen:
            seen.append(key)
            deduped.append(item)
    return deduped


def main():
    print(f"fetch_news.py — {datetime.now().isoformat()}")
    
    all_items = []
    for feed in FEEDS:
        print(f"  Fetching {feed['name']}...")
        items = fetch_feed(feed)
        print(f"    Got {len(items)} items")
        all_items.extend(items)
    
    # Sort by date (most recent first), filter, deduplicate
    all_items = [i for i in all_items if is_relevant(i['title'])]
    all_items.sort(key=lambda x: x.get('pub_dt') or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    all_items = deduplicate(all_items)
    
    # Build output headlines (top 10)
    headlines = []
    for i, item in enumerate(all_items[:10]):
        tag, cls = categorise(item['title'])
        headlines.append({
            'id': str(i + 1),
            'tag': tag,
            'tag_class': cls,
            'headline': item['title'],
            'date': item['pub_str'],
            'source': item['source'],
            'url': item['url'],
        })
    
    if not headlines:
        print("WARNING: No headlines fetched, keeping existing data", file=sys.stderr)
        sys.exit(0)
    
    output = {
        '_meta': {
            'updated': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'update_frequency': 'daily',
            'sources': [f['name'] for f in FEEDS],
            'note': 'Auto-fetched daily at 06:00 UTC.',
        },
        'headlines': headlines,
    }
    
    with open(DATA_FILE, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"Saved {len(headlines)} headlines to {DATA_FILE}")
    for h in headlines:
        print(f"  [{h['tag']}] {h['headline'][:70]}")


if __name__ == '__main__':
    main()
