#!/usr/bin/env python3
"""
fetch_manifesto.py
Scrapes Full Fact's Government Tracker to update manifesto pledge statuses.
Runs monthly (1st of each month) via GitHub Actions.

Full Fact publishes individual pledge pages at:
  https://fullfact.org/government-tracker/
Each pledge has a machine-readable status badge.

Note: This is a best-effort scrape. If Full Fact changes their markup,
the script falls back to preserving existing data.
"""

import json
import os
import sys
import re
import urllib.request
from datetime import datetime, date

DATA_FILE = os.path.join(os.path.dirname(__file__), '..', 'data', 'manifesto.json')

# Status text → internal key mapping
STATUS_MAP = {
    'achieved': 'achieved',
    'on track': 'on_track',
    'in progress': 'in_progress',
    'off track': 'off_track',
    'broken': 'not_kept',
    'not kept': 'not_kept',
    'unclear': 'unclear',
    'wait and see': 'wait_and_see',
    'wait & see': 'wait_and_see',
}

TRACKER_URL = 'https://fullfact.org/government-tracker/'


def fetch_html(url: str) -> str:
    """Fetch HTML from a URL."""
    try:
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'Spectrm/1.0 (+https://spectrm.app); data journalism research',
                'Accept': 'text/html',
            }
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"  WARNING: Could not fetch {url}: {e}", file=sys.stderr)
        return ''


def parse_pledge_status(html: str) -> str | None:
    """Extract pledge status from a Full Fact pledge page."""
    # Full Fact uses a verdict/status element — try several patterns
    patterns = [
        r'class="[^"]*verdict[^"]*"[^>]*>\s*([^<]{3,30})',
        r'class="[^"]*status[^"]*"[^>]*>\s*([^<]{3,30})',
        r'data-status="([^"]+)"',
        r'<span[^>]*class="[^"]*label[^"]*"[^>]*>([^<]{3,20})</span>',
    ]
    for pattern in patterns:
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            raw = match.group(1).strip().lower()
            mapped = STATUS_MAP.get(raw)
            if mapped:
                return mapped
    return None


def recount(pledges: list[dict]) -> dict:
    """Recount pledge statuses."""
    counts = {k: 0 for k in STATUS_MAP.values()}
    for p in pledges:
        status = p.get('status', 'wait_and_see')
        if status in counts:
            counts[status] += 1
    return {
        'total': len(pledges),
        'achieved': counts['achieved'],
        'on_track': counts['on_track'],
        'in_progress': counts['in_progress'],
        'off_track': counts['off_track'],
        'not_kept': counts['not_kept'],
        'unclear': counts['unclear'],
        'wait_and_see': counts['wait_and_see'],
    }


def main():
    print(f"fetch_manifesto.py — {datetime.now().isoformat()}")
    
    # Load existing data
    try:
        with open(DATA_FILE) as f:
            current = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print("ERROR: Could not load existing manifesto.json", file=sys.stderr)
        sys.exit(1)
    
    pledges = current.get('pledges', [])
    updated_count = 0
    
    print(f"Checking {len(pledges)} pledges...")
    
    for i, pledge in enumerate(pledges):
        src = pledge.get('src', '')
        if not src:
            continue
        
        url = f"https://{src}" if not src.startswith('http') else src
        print(f"  [{i+1}/{len(pledges)}] {pledge['pledge'][:50]}...")
        
        html = fetch_html(url)
        if not html:
            continue
        
        new_status = parse_pledge_status(html)
        if new_status and new_status != pledge.get('status'):
            print(f"    STATUS CHANGE: {pledge['status']} → {new_status}")
            pledge['status'] = new_status
            pledge['updated'] = date.today().strftime('%b %Y')
            updated_count += 1
        else:
            # Update the checked date even if no change
            pledge['updated'] = date.today().strftime('%b %Y')
    
    # Recount summary
    current['summary'] = recount(pledges)
    current['pledges'] = pledges
    current['_meta']['updated'] = date.today().isoformat()
    
    with open(DATA_FILE, 'w') as f:
        json.dump(current, f, indent=2)
    
    print(f"\nDone. {updated_count} status changes. Summary: {current['summary']}")


if __name__ == '__main__':
    main()
